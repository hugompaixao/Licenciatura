package screenpac.grid;

/**
 * Created by IntelliJ IDEA.
 * User: sml
 * Date: 29-Mar-2010
 * Time: 16:15:17
 * To change this template use File | Settings | File Templates.
 */
public class SizeTest {
    public static void main(String[] args) {
        double x = Math.pow(20, 6);
        System.out.println("x = " + x);
        System.out.println(Math.log(2));
    }
}
