package screenpac.controllers;

import screenpac.model.GameStateInterface;

public class PredictiveController implements AgentInterface {
    // this screenpac.game will aim to follow a path, and turn early
    public int action(GameStateInterface gs) {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
