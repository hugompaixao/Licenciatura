package screenpac.log;

import screenpac.model.GameState;

import java.util.List;

public class Logger {
    List<GameState> stateList;
}
